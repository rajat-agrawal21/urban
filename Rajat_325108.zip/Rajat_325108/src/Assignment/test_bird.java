package Assignment;

public class test_bird {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		parrot p1 = new parrot();
		parrot p2 = new parrot();
		parrot p3 = new parrot();
		
		owl o1 = new owl();
		owl o2 = new owl();
		
		p1.climate = "Warm";
		p1.region = "Australia, Asia, Central America and South America";
		p1.sound = "Pleasant sound and can also imitate human speech";
		p1.color = "Light Green";
		p1.food  = "Green Chillies , fruits, Small Insects";
		p1.name = "Mitthu";
		p1.weight = 40;
		p1.fly();
		p1.weight();
		p1.display_parrot();
		
		p2.climate = "Little Warm";
		p2.region = "Australia, Asia, Central America and South America";
		p2.sound = "Pleasant sound and can also imitate human speech";
		p2.color = "Green";
		p2.food  = "Green Chillies,buds, nuts, seeds,Small Insects";
		p2.name = "Totii";
		p2.weight = 70;
		p2.fly();
		p2.weight();
		p2.display_parrot();
		
		p3.climate = "Warm";
		p3.region = "Australia, Asia, Central America and South America";
		p3.sound = "Pleasant sound and can also imitate human speech";
		p3.color = "Green with yellow shades";
		p3.food  = "Green Chillies , fruits,seeds, Small Insects";
		p3.name = "Batuk";
		p3.weight = 90;
		p3.fly();
		p3.weight();
		p3.display_parrot();
		
		o1.region = "All regions except polar ice cap";
		o1.eyesight = "Very sharp";
		o1.sound = "Very unpleasant";
		o1.color = "Grey";
		o1.food = "Squirells, insects";
		o1.name = "Ullu";
		o1.weight = 10000;
		o1.fly();
		o1.weight();
		o1.display_owl();
		
		o1.region = "All regions except polar ice cap";
		o1.eyesight = "Very sharp";
		o1.sound = "Very unpleasant";
		o1.color = "Grey with black Shades";
		o1.food = "Squirells, insects";
		o1.name = "Kalu";
		o1.weight = 8000;
		o1.fly();
		o1.weight();
		o1.display_owl();
	}

}
