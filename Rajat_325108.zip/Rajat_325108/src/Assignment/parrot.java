package Assignment;

public class parrot extends bird {
	
	String climate;
	String region;
	String sound;
	
	public void fly() {
		System.out.println("They generally can fly higher");
	}
	
	public void weight() {
		System.out.println("They are much lighter than other birds");
	}
	
public void display_parrot() {
		
		System.out.println("Region in which they most likely to find:" +this.region + "Climate they like:" +this.climate + "Sound:" +this.sound);
		System.out.println("Color:" +this.color + "Food it likes:" +this.food + "Its name:" +this.name + "Its weight:" +this.weight);
	}
	
}
