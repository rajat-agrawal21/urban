package Assignment;

public class bird {
	
	String color;
	String food;
	String name;
	int weight;
	
	public void eats() {
		System.out.println("the bird eats:" +food);
	}
}
