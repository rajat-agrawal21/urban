package Assignment;

public class Armstrong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum =0,j=0;
		int[] arr = new int[4];
		
		for(int i =2;i<1000;i++) {
			int temp =i;
			
			while(temp!=0) {
				int rem = temp%10;
				sum = sum + rem*rem*rem;
				temp = temp/10;
			}
			
			if(sum == i) {
				arr[j] = i;
				j++;
	}
		
	}
		System.out.println(arr);
}
}
