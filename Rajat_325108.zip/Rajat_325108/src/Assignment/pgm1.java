package Assignment;

import java.util.ArrayList;

public class pgm1 {

		static ArrayList<String> arr;
	static ArrayList<String> get_each_word(String line){
		
		arr = new ArrayList<String>();
		int l=0,l1=0,p=0;
		String s1;
	 	
 		while(p!= -1) {
 		 l = line.indexOf(" ",l+1);
 		// System.out.println("l:" +l);
 		 //System.out.println("l1:" +l1);
 		p=l;
 		 if(l == -1) 
			 l= line.length();
 		s1 = line.substring(l1,l);
 		l1 =l+1;
 		arr.add(s1);
 		}
 		//System.out.println(arr);
		return arr;
	}
	
	public static int is_count(String s1)
	{
		int count =0;
		for(int i=0;i<s1.length();i++)
		{
			char c= s1.charAt(i);
			if((c=='a')|| (c=='e') || (c=='i') || (c=='o') || (c=='u'))
    		{
    			count++;
    		}
			
		}
		return count;
		
	}
	
	static ArrayList<String> count_vowels(ArrayList<String> s ){
		String str1;
		ArrayList<String> arr1 = new ArrayList<String>();
		//int count =0;
		for(int i=0;i<s.size();i++) {
			str1 = s.get(i);
			
			if(is_count(str1)>=3) {
				arr1.add(str1);
			}
			//for(int j=0;j<str1.length();j++) {
				//if(str1.charAt(j) == 'a' || str1.charAt(j) == 'e' || str1.charAt(j) == 'i' || str1.charAt(j) == 'o' || str1.charAt(j) == 'u') 
				//	count ++;
			}
			
		
		return arr1;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "I have learnt loops, oops concepts, Inheritance, exception handling, arraylist and string handling ";
		//String s1;
		ArrayList<String> s = new ArrayList<String>();
		ArrayList<String> s2 = new ArrayList<String>();
		
		s = get_each_word(str);
		//System.out.println(s);
		s2 =count_vowels(s);
		System.out.println(s2);
	}

}
