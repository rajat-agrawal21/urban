package Assignment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class pgm3 {
	
	public ArrayList<product_info> read_excel()
	   {
		ArrayList<product_info> arr_li =new ArrayList<product_info>();
		try
		{
			File f= new File("C:\\Users\\rajat.agrawal\\Documents\\Book2.xlsx");
			FileInputStream fis =new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet9");
			
			int fist =sh.getFirstRowNum();
			int last =sh.getLastRowNum();
			
			int nor=last-fist+1;
			for(int i=fist+1;i<=last;i++)
			{
				product_info pg= new product_info();
				
				XSSFRow r= sh.getRow(i);
				
				XSSFCell c= r.getCell(0);
				pg.Pid= (int)c.getNumericCellValue();
				
				XSSFCell c1= r.getCell(1);
				pg.Prodname = c1.getStringCellValue();
				
				XSSFCell c2= r.getCell(2);
				pg.Price_per_unit = (int)c2.getNumericCellValue();
				
				XSSFCell c3= r.getCell(3);
				pg.no_of_unit = (int)c3.getNumericCellValue();
				
				
				pg.calc_price();
				System.out.println(pg.price);
				pg.calc_grade();
				System.out.println(pg.grade);
				arr_li.add(pg);
				
			}
		}
		catch (FileNotFoundException e) {
			  e.printStackTrace();	
			}
			catch( IOException e)
			{
				e.printStackTrace();
			}
			return arr_li;
		  
	  }
	   public void write_excel(ArrayList<product_info>arr)
	   {
		   int row=1;
		   try
		   {
			   File f= new File("C:\\Users\\rajat.agrawal\\Documents\\Book2.xlsx");
			   FileInputStream fis =new FileInputStream(f);
			   XSSFWorkbook wb =new XSSFWorkbook(fis);
			   XSSFSheet sh = wb.getSheet("Sheet9");
			   for(product_info pf : arr)
			   {
				   XSSFRow r= sh.getRow(row);
				   XSSFCell c= r.createCell(4);
				   c.setCellValue(pf.price);
				   
				  // XSSFRow r= sh.getRow(row);
				   XSSFCell c1= r.createCell(5);
				   c1.setCellValue(pf.grade);
				   row++;
			   }
			  
			   FileOutputStream fos =new FileOutputStream(f);
				wb.write(fos);
				
			}
				catch (FileNotFoundException e) {
					  e.printStackTrace();	
					}
					catch( IOException e)
					{
						e.printStackTrace();
					}           
		   
	   }
	}
	

