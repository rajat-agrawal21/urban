package Assignment;

public class Student {

		int rollno;
		String name;
		int java;
		int sel;
		int avg;
		
		public void marks_info(int rollno, String name, int java, int sel) {
			this.rollno = rollno;
			this.name = name;
			this.java = java;
			this.sel = sel;
			
		}
		public void average()
		{
			this.avg= (this.java+this.sel)/2;
			
			if(avg>=65)
			{
				System.out.println("rollno is:"+ this.rollno + " "+ " name is: "+ this.name + " "+ "java marks is:"+ this.java+ " "+ " sel marks is: "+ this.sel+ " "+ "average is:" + this.avg);
			}
			
		}
		public static void main(String args[])
		{
			Student s1= new Student();
			Student s2= new Student();
			Student s3= new Student(); 
			
			s1.marks_info(1,"Rishabh",70,87);
			s2.marks_info(2,"Rajat",88,70);
			s3.marks_info(3,"Ankit",56,80);
			
			s1.average();
			s2.average();
			s3.average();
		}
	}
