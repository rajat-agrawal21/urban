package Assignment;

import java.util.ArrayList;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			
			pgm3 p1= new pgm3();
			ArrayList<product_info> arr_li1 =new ArrayList<product_info>();
			arr_li1=p1.read_excel();
			p1.write_excel(arr_li1);

		
	}

}
