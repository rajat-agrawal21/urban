package Assignment;

public class product_info {
		int Pid;
		String Prodname;
		int Price_per_unit;
		int no_of_unit;
		int price;
		String grade;
		
		public void calc_price()
		{
			this.price=this.Price_per_unit* this.no_of_unit;
		}
		public void calc_grade()
		{
			if(price<25000)
				this.grade= "A";
			if(price>=25000)
				this.grade=" B";
		}
	}

