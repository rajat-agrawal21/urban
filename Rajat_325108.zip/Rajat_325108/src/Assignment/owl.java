package Assignment;

public class owl extends bird{
	
	String region;
	String eyesight;
	String sound;
	
	public void fly() {
		System.out.println("They generally can't fly higher");
	}
	
	public void weight() {
		System.out.println("They are much heavy than other birds");
	}
	
	public void display_owl() {
		
		System.out.println("Region in which they most likely to find:" +this.region + "Eyesight:" +this.eyesight + "Sound:" +this.sound);
		System.out.println("Color:" +this.color + "Food it likes:" +this.food + "Its name:" +this.name + "Its weight:" +this.weight);
	}
	
}
