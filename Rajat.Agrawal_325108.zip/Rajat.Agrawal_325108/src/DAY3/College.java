package DAY3;
//import DAY3.Student;
public class College {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student rakesh = new Student();
		rakesh.roll_no = 73;
		rakesh.name = "Rakesh";
		rakesh.m1 = 83;
		rakesh.m2 = 91;
		rakesh.average();
		System.out.println(rakesh.avg);
		
		Student priya = new Student();
		priya.roll_no = 65;
		priya.name = "Priya";
		priya.m1 = 85;
		priya.m2 = 61;
		priya.average();
		System.out.println(priya.avg);
		
	}

}
