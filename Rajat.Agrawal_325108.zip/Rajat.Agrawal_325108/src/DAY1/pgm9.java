package DAY1;

import java.util.*;
public class pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b;
		
		System.out.println("Enter a value of a");
		Scanner sc = new Scanner(System.in);
		a = sc.nextInt();
		
		System.out.println("Enter a value of b");
		Scanner sc1 = new Scanner(System.in);
		b = sc1.nextInt();

		if(a>b)
		 System.out.println("a is greater than b");
		else if(a==b)
			System.out.println("a is equal to b");
		else
		System.out.println("a is lesser than b");
		
		sc.close();
		sc1.close();
		
	}

}
