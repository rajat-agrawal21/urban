package DAY1;

public class pgm1 {

	
		// TODO Auto-generated method stub
		
	static boolean isPrime(int n)
	{ if(n<=1)
		return false;
		
	for(int i=2;i<n;i++)
	{ if(n % i == 0 )
		return false;
	}
	return true;
	}
	public static void main(String[] args) {
	int count=0;
		for(int n=1;n<=30;n++)
		{ if(isPrime(n))
			System.out.print(+n + " ");
		count = count + n;
		}
		System.out.println(+count);
	}
}


