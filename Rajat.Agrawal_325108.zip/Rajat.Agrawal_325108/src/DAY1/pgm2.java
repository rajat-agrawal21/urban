package DAY1;
import java.util.*;
public class pgm2 {
    public static void main(String[] args) {
    	
    	System.out.println("Enter any number");
    	Scanner sc = new Scanner(System.in);
    	int num = sc.nextInt();
    	
        int rev = 0, remainder, orig;
        orig = num;
         
        while( num != 0 )
        {
            remainder = num % 10;
            rev = rev * 10 + remainder;
            num  /= 10;
        }
        
        if (orig == rev)
            System.out.println(orig + " is a palindrome.");
        else
            System.out.println(orig + " is not a palindrome.");
        sc.close();
    }
}