package DAY1;
import java.util.*;
public class pgm12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter marks of student in Maths");
		Scanner sc1 = new Scanner(System.in);
		float m = sc1.nextInt();
		
		System.out.println("Enter marks of student in Science");
		Scanner sc2 = new Scanner(System.in);
		float s = sc2.nextInt();
		
		System.out.println("Enter marks of student in English");
		Scanner sc3 = new Scanner(System.in);
		float e = sc3.nextInt();
		
		float marks = (m+s+e)/3;
		
		if((marks)>=60)
			System.out.println("Congrats you have got first class");
		else if((marks)>=50)
			System.out.println("You have got a secomd class");
		else if((marks)>=35)
			System.out.println("You have got third class");
		else 
			System.out.println("You are failed");
		
		sc1.close();
		sc2.close();
		sc3.close();
	}

}
