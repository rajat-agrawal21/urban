package DAY1;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=10;
		System.out.println(x++);
		System.out.println(++x);
		System.out.println(x--);
	}

}
