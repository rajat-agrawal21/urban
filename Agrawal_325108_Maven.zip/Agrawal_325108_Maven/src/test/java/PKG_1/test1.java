package PKG_1;

import org.testng.annotations.Test;

public class test1 {
  @Test
  public void f() {
	  System.out.println("in the maven folder and pkg_1 pkg");
  }
}
