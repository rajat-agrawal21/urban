package SDAY3;

public class demo {
	String email;
	String pwd;
	String exp;
	String act;
	String res;
}
