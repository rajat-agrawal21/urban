package SDAY3;

public class demo1 {
	
	public String fname;
	public String lname;
	public String email;
	public String pwd;
	public String cpwd;
	public String exp;
	public String act;
	public String res;
}
