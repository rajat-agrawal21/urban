package SDAY3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm3 {

	 static demo d;
	 
		public static demo read_excel() {
	
			try {
				
				d= new demo();
				
			File f = new File("C:\\Users\\rajat.agrawal\\Documents\\Book2.xlsx");
			FileInputStream fin = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fin);
			XSSFSheet sh = wb.getSheet("Sheet12");
			
			XSSFRow r = sh.getRow(1);
			
			XSSFCell c1 = r.getCell(0);
			d.email =c1.getStringCellValue();
			
			XSSFCell c2 = r.getCell(1);
			d.pwd =c2.getStringCellValue();
			
			XSSFCell c3 = r.getCell(2);
			d.exp =c3.getStringCellValue();
			}
			
			catch (FileNotFoundException e) {
				  e.printStackTrace();	
				}
				catch( IOException e)
				{
					e.printStackTrace();
				}
			return d;
		}
		
		public static void login(demo d2) {
		
			 String url = "http://demowebshop.tricentis.com/login";
				
				System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
				WebDriver dr = new ChromeDriver();
				dr.get(url);
			
				dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(d2.email);
				dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(d2.pwd);
			    dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
			
			String s  = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();			
			String s1 = "rajatmittald6@gmail.com";
			
			if(s.equals(s1)) {
				System.out.println("login pass");
				d.act = "Success";
				d.res = "Pass";
		}
			else System.out.println("login fails");
		}
		
				
		public static void write_excel() {
			
			try {
				File f = new File("C:\\\\Users\\\\rajat.agrawal\\\\Documents\\\\Book2.xlsx");
				FileInputStream fin = new FileInputStream(f);
				XSSFWorkbook wb = new XSSFWorkbook(fin);
				XSSFSheet sh = wb.getSheet("Sheet12");
				
				XSSFRow r = sh.getRow(1);
				
				XSSFCell c4 = r.createCell(3);
				c4.setCellValue(d.act);
				
				XSSFCell c5 = r.createCell(4);
				c5.setCellValue(d.res);
				
				FileOutputStream fout =new FileOutputStream(f);
				wb.write(fout);
			}
			catch (FileNotFoundException e) {
				  e.printStackTrace();	
				}
				catch( IOException e)
				{
					e.printStackTrace();
				}
			
		}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			demo d1 = new demo();
			d1 = read_excel();
			login(d1);
			write_excel();
	
			
		}
	}


