package SDAY3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 String url = "https://ultimateqa.com/simple-html-elements-for-automation/";
			
			System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
			WebDriver dr = new ChromeDriver();
			dr.get(url);
			
		//dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[8]/div/div/div/form/input[1]")).click();
		//dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[8]/div/div/div/form/input[2]")).click();
		
		dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[10]/ul/li[1]/a")).click();
		String a = dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[10]/div/div[1]/div")).getText();
		System.out.println(a);
		/*String e = "tab 1 content";
		if(a.equals(e)) {
			System.out.println("Tab 1 pass");
		}
		else System.out.println("Tab 1 fails");
		
		dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[10]/ul/li[2]/a")).click();
		String a1 = dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[10]/div/div[2]/div")).getText();
		String e1 = "tab 2 content";
		if(a1.equals(e1)) {
			System.out.println("Tab 2 pass");
		}
		else System.out.println("Tab 2 fails"); */
		
	}

}
