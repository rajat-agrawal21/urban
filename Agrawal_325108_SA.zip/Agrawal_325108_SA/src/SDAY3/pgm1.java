package SDAY3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
  String url = "https://ultimateqa.com/simple-html-elements-for-automation/";
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get(url);
		
		dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[2]/div/div[3]/div/div/div/div/form/button")).click();
		
		String actual =dr.findElement(By.xpath("//*[@id=\"post-4690\"]/div[1]/h1")).getText();
		String expected = "Button success";
		
		if(actual.equals(expected)) {
			System.out.println("Pass");
		}
		else System.out.println("Fail");
	}

}
