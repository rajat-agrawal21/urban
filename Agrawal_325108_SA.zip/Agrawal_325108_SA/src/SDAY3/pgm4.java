package SDAY3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm4 {
		
		    static demo1 d1;
		 
			public static demo1 read_excel() {
		
				try {
					
					d1 = new demo1();
					
				File f = new File("C:\\\\Users\\\\rajat.agrawal\\\\Documents\\\\Book2.xlsx");
				FileInputStream fin = new FileInputStream(f);
				XSSFWorkbook wb = new XSSFWorkbook(fin);
				XSSFSheet sh = wb.getSheet("Sheet13");
				
				XSSFRow r = sh.getRow(1);
				
				XSSFCell c1 = r.getCell(0);
				d1.fname =c1.getStringCellValue();
				
				XSSFCell c2 = r.getCell(1);
				d1.lname =c2.getStringCellValue();
				
				XSSFCell c3 = r.getCell(2);
				d1.email =c3.getStringCellValue();
				
				XSSFCell c4 = r.getCell(3);
				d1.pwd =c4.getStringCellValue();
				
				XSSFCell c5 = r.getCell(4);
				d1.cpwd =c5.getStringCellValue();
				
				XSSFCell c6 = r.getCell(5);
				d1.exp =c6.getStringCellValue();
				}
				
				catch (FileNotFoundException e) {
					  e.printStackTrace();	
					}
					catch( IOException e)
					{
						e.printStackTrace();
					}
				return d1;
			}
			
			public static void registration(demo1 d2) {
			
				 String url = "http://demowebshop.tricentis.com/register";
					
					System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
					WebDriver dr = new ChromeDriver();
					dr.get(url);
				
					dr.findElement(By.xpath("//*[@id=\"gender-male\"]")).click();
					dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys(d2.fname);
					dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys(d2.lname);
					dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(d2.email);
					dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(d2.pwd);
					dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys(d2.cpwd);
						
				    dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
				
				String s  = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]")).getText();			
				String s1 = "Your registration completed";
				
				if(s.equals(s1)) {
					System.out.println("Registration pass");
					d1.act = "Success";
					d1.res = "Pass";
			}
				else System.out.println("Registration fails");
				
				dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
			}
			
					
			public static void write_excel() {
				
				try {
					File f = new File("C:\\\\Users\\\\rajat.agrawal\\\\Documents\\\\Book2.xlsx");
					FileInputStream fin = new FileInputStream(f);
					XSSFWorkbook wb = new XSSFWorkbook(fin);
					XSSFSheet sh = wb.getSheet("Sheet13");
					
					XSSFRow r = sh.getRow(1);
					
					XSSFCell c7 = r.createCell(6);
					c7.setCellValue(d1.act);
					
					XSSFCell c8 = r.createCell(7);
					c8.setCellValue(d1.res);
					
					FileOutputStream fout =new FileOutputStream(f);
					wb.write(fout);
				}
				catch (FileNotFoundException e) {
					  e.printStackTrace();	
					}
					catch( IOException e)
					{
						e.printStackTrace();
					}
				
			}
			
		public static void main(String[] args) {
			// TODO Auto-generated method stub
				demo1 d3 = new demo1();
				d3 = read_excel();
				registration(d3);
				write_excel();
		
				
			}
	}


