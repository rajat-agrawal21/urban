package SDAY5;

import org.testng.annotations.Test;

public class NewTest {
  @Test
  public void t1() {
	  System.out.println("In test t1");
  }
  
  @Test
  public void t2() {
	  System.out.println("In test t2");
  }
  
  @Test
  public void t3() {
	  System.out.println("In test t3");
  }
  
}
