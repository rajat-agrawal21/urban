package SDAY5;

import org.testng.annotations.Test;

import SDAY4.login_data;
import SDAY4.test_login;

public class NewTest3 {
	
	test_login loginobj;
	login_data ldata,ldata_out;
	
      @Test
      public void t1() {
	  
	  ldata = new login_data();
	  ldata_out = new login_data();
	  loginobj = new test_login();
	  
	  ldata.uid = "rajatmittald6@gmail.com";
	  ldata.pwd = "mittaldemo21";
	  ldata.exp_res1 = "SUCCESS";
	  
	  ldata_out = loginobj.login(ldata);
	  System.out.println("ldata_out.act_res1:" + ldata_out.act_res1);
			  
  }
}
