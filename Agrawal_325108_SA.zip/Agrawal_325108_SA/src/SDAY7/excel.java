package SDAY7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel {

	
	public static String[][] testdata;
	public static int rowno,colno;
	
	/*public static void main(String[] args) {
		// TODO Auto-generated method stub

		testdata = new String[2][3];
		for(rowno=1;rowno<=2;rowno++) {
			get_test_data();
		}
		
		System.out.println("Test data Displayed");
		//display_testdata();	
	}*/
	
	public static void get_test_data() {
		
		int c; String s=null, s1=null, s2 = null;
		
		try {
			
			System.out.println("in test data row =" +rowno);
			File f = new File("C:\\Users\\rajat.agrawal\\Documents\\Book2.xlsx");
			FileInputStream fin = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fin);
			XSSFSheet sh = wb.getSheet("Sheet17");
							
			XSSFRow row = sh.getRow(rowno);
			
			XSSFCell cell1 = row.getCell(0);
			testdata[rowno-1][0]= cell1.getStringCellValue();
			
			XSSFCell cell2 = row.getCell(1);
			testdata[rowno-1][1]= cell2.getStringCellValue();
			
			XSSFCell cell3 = row.getCell(2);
			testdata[rowno-1][2]= cell3.getStringCellValue();
			
		}
		catch (FileNotFoundException e) {
			  e.printStackTrace();	
			}
			catch( IOException e)
			{
				e.printStackTrace();
			}
	}

}
