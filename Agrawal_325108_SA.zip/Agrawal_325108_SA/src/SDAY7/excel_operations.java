package SDAY7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_operations {
		
  String data1;
		
		public String read_excel(int r,int c) {
					
			try {
				
				File f = new File("C:\\Users\\rajat.agrawal\\Documents\\Book2.xlsx");
				FileInputStream fin = new FileInputStream(f);
				XSSFWorkbook wb = new XSSFWorkbook(fin);
				XSSFSheet sh = wb.getSheet("Sheet16");
								
				XSSFRow row = sh.getRow(r);
				
				XSSFCell cell1 = row.getCell(c);
				data1 = cell1.getStringCellValue();											
		}
			catch (FileNotFoundException e) {
				  e.printStackTrace();	
				}
				catch( IOException e)
				{
					e.printStackTrace();
				}
			return data1;
	}
		
		public static void write_excel(int r) {
			
			try {
			File f = new File("C:\\Users\\rajat.agrawal\\Documents\\Book2.xlsx");
			FileInputStream fin = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fin);
			XSSFSheet sh = wb.getSheet("Sheet16");
							
			XSSFRow row = sh.getRow(r);
			
			XSSFCell cell1 = row.createCell(6);
			cell1.setCellValue("Pass");
			
			FileOutputStream fout =new FileOutputStream(f);
			wb.write(fout);
			
			}
			catch (FileNotFoundException e) {
				  e.printStackTrace();	
				}
				catch( IOException e)
				{
					e.printStackTrace();
				}
		}
	}

// excel_operrations, all_webelement_fns , driver_script
