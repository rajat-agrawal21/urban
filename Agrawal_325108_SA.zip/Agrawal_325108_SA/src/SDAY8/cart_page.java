package SDAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class cart_page {

	WebDriver dr;
	
public cart_page(WebDriver dr) {
		
		this.dr = dr;
		PageFactory.initElements(dr, this);		
	}
	public String get_product_name() {
		
		String xp = "//*[@id=\"item_4_title_link\"]/div";
				String prod_name =dr.findElement(By.xpath(xp)).getText();
				return prod_name;
				
		
	}
	}