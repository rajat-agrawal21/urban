package SDAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class test1 {
	
	login_page lp;
	home_page hp;
	cart_page cp;
	WebDriver dr;
	
	@BeforeMethod
	public void bc() {
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		lp = new login_page(dr);
		hp= new home_page(dr);
		cp= new cart_page(dr);
	}
		
	 @Test
  public void t1() {
		 
		 lp.do_login("standard_user", "secret_sauce");		
		 hp.add_to_cart(1);
		 
		 String e_pn= hp.get_prod_name(1);
		 //System.out.println("After get prod name" + e_pn);
		 hp.click_cart();

		 //String a_pn= dr.findElement(By.xpath("//div[@class='cart_item_label']//div[@class='inventory_item_name']")).getText();
	
		 String a_pn = cp.get_product_name();
		 SoftAssert sa= new SoftAssert();
		 sa.assertEquals(a_pn, e_pn);
		 sa.assertAll();
  }
}
