package SDAY4;

public class login_data {
	
	
	public String uid,pwd,exp_res1,act_res1,test_res;
	public String exp_msg1,exp_msg2,act_msg1,act_msg2;
	
	public login_data(String uid,String pwd,String exp_res , String act_res, String test_res ) {
		
		this.uid = uid;
		this.pwd = pwd;
		this.exp_res1 =exp_res;
		this.act_res1 = exp_res;
		this.test_res = test_res;
	}
	
	public login_data() {
		
	}
	
	public void display() {
		System.out.println("UID:" +this.uid 
				+ "\n PWD:" +this.pwd
				+ "\n Exp_Res:" +this.exp_res1
				+"\n Act Res:" +this.act_res1
				+ "\n Test Res:" +this.test_res
				+ "\n exp_msg1:" +this.exp_msg1
				+ "\n exp_msg2:" +this.exp_msg2
				+ "\n act_msg1:" +this.act_msg1
				+ "\n act_msg2:" +this.act_msg2
				+ "\n ====================");
	}
}
