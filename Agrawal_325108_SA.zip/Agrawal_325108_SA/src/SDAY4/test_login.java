package SDAY4;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test_login extends excel{

	public static login_data login(login_data ldata) {
		
		String url = "http://demowebshop.tricentis.com/login";
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get(url);
	
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(ldata.uid);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(ldata.pwd);
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	
	boolean f = dr.getTitle().contains("Login");
	
	if(!f) {
		ldata.act_res1 = "SUCCESS";
		System.out.println("Login Success");
	}
	
	else
		
		{
		ldata.act_res1 = "FAILURE";
		System.out.println(ldata.act_res1);
		
	    ldata.act_msg1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
	    ldata.act_msg2 =dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
	}
	
	/*if(ldata.exp_res1.equals("FAILURE")) {
		System.out.println("Ldata.exp_msg1:" +ldata.exp_msg1 + "ldata.act_msg1:" +ldata.act_msg1 
				+ "ldata.exp_msg2:" +ldata.exp_msg2 + "ldata.act_msg2:" + ldata.act_msg2 );
		
		if(ldata.act_msg1.equals(td.exp_msg1) && ldata.act_msg2.equals(td.exp_msg2)) {
			ldata.test_res = "PASS";
			//System.out.println("ramu");
		}
		else
			{
			ldata.test_res = "FAIL";
			//System.out.println("shyamu");
			}
		
	}
	else
	{
		ldata.test_res = "PASS";
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		
		try {
			Thread.sleep(2000);
		}
		
		catch(InterruptedException e){
			e.printStackTrace();
		}
		dr.close();
		
	}*/
	
	return ldata;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int c=0;
		
		//data_al = new ArrayList<login_data>();
		//login_data ld = new login_data();
		
		for(int r=1;r<=2;r++) {
					
		
		
		get_test_data(r);
		//System.out.println("size:" +data_al.size());
		
	//	for(login_data ld: data_al) {
			
			login_data ld1 = login(td);
			//System.out.println("c=" +c);
			//data_al.set(c, ld1);
			ld1.display();
			write_excel(r,ld1);
			//c++; 
		
	}
		
		
	}

}
