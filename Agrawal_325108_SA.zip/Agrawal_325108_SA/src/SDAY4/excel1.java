package SDAY4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel1 extends login_data {

	
	public static ArrayList<login_data> data_al = new ArrayList<login_data>();
	static login_data td;
	
	/*public static void main(String [] args) {
		
		int r=1;
		data_al = new ArrayList<login_data>();
		get_test_data(r);
	} */
	
	public static void get_test_data() {
		int c;
		String s= "";
		
		
		try {
							
			File f = new File("C:\\Users\\rajat.agrawal\\Documents\\Book2.xlsx");
			FileInputStream fin = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fin);
			XSSFSheet sh = wb.getSheet("Sheet14");
			
			for(int r=1;r<=2;r++) {
				
			td = new login_data();
						
			XSSFRow row = sh.getRow(r);
			
			XSSFCell cell1 = row.getCell(0);
			td.uid = cell1.getStringCellValue();
			
			XSSFCell cell2 = row.getCell(1);
			td.pwd = cell2.getStringCellValue();
			
			XSSFCell cell3 = row.getCell(2);
			td.exp_res1 = cell3.getStringCellValue();
			
			XSSFCell cell4 = row.getCell(3);
			td.exp_msg1= cell4.getStringCellValue();
			
			XSSFCell cell5 = row.getCell(4);
			td.exp_msg2 = cell5.getStringCellValue();
			
			data_al.add(td);
			}
		
	}
		
		catch (FileNotFoundException e) {
			  e.printStackTrace();	
			}
			catch( IOException e)
			{
				e.printStackTrace();
			}
		}
		
	
	
	public static void write_excel(ArrayList<login_data> arr_li) {
		
		int r=1;
		
		File f = new File("C:\\Users\\rajat.agrawal\\Documents\\Book2.xlsx");
		String s= "";
		try {
			
			FileInputStream fin = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fin);
			XSSFSheet sh = wb.getSheet("Sheet14");
			
			for(login_data ld2 : arr_li) {
				
			
			XSSFRow row = sh.getRow(r);
			
			XSSFCell cell6 = row.createCell(5);
			cell6.setCellValue(ld2.act_res1);
			
			if(ld2.act_res1.equals("FAILURE")) {
				
				XSSFCell cell7 = row.createCell(6);
				cell7.setCellValue(ld2.act_msg1);
				
				XSSFCell cell8 = row.createCell(7);
				cell8.setCellValue(ld2.act_msg2);				
			}
			
			XSSFCell cell9 = row.createCell(8);
			cell9.setCellValue(ld2.test_res);
			r++;
			}
			FileOutputStream fout = new FileOutputStream(f);
			wb.write(fout);
		}
		
		catch (FileNotFoundException e) {
			  e.printStackTrace();	
			}
			catch( IOException e)
			{
				e.printStackTrace();
			}
		
	}
}
