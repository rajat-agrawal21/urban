package SDAY4;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver dr;
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		dr = new ChromeDriver();
		dr.get("https://www.naukri.com/");
		
		String hnd = dr.getWindowHandle();
		//System.out.println(hnd);
		for(String handle : dr.getWindowHandles()) {
			dr.switchTo().window(handle);
			String title = dr.getTitle();
			System.out.println(title);
		}
	}

}
