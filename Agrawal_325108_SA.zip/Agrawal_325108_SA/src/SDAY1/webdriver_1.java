package SDAY1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class webdriver_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.facebook.com");
		
		dr.findElement(By.name("email")).sendKeys("rajatmittald5@gmail.com");
		dr.findElement(By.name("pass")).sendKeys("12234");
		dr.findElement(By.xpath("//*[@id='loginbutton']")).click();
		
	/*	WebElement wel = dr.findElement(By.id("day"));
		Select sel = new Select(wel);
		sel.selectByVisibleText("21");
		
		WebElement wel1 = dr.findElement(By.id("month"));
		Select sel1 = new Select(wel1);
		sel1.selectByVisibleText("Mar");
		
		WebElement wel2 = dr.findElement(By.id("year"));
		Select sel2 = new Select(wel2);
		sel2.selectByVisibleText("1996");  */
		
		/*String title = dr.getTitle();
		System.out.println("Title:" +title);
		
		List lb = dr.findElements(By.name("sex"));
		((WebElement) lb.get(0)).click();*/
		
		/*String actual = dr.findElement(By.xpath("//*[@id=\"u_0_a\"]/div[1]/div[1]/div/a/span/span")).getText(); 
		String expected = "Rajat";
		
		if(actual.equals(expected)) {
			System.out.println("You have logged in to the correct id");
		} */
				
	}

}
