package hybrid;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class all_methods {

	static WebDriver dr;
	static String result;
	
	public static void launchBrowser(String xPath) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr = new ChromeDriver();
		dr.get(xPath);
		
	}

	public static void enter_text(String xPath, String testdata) {
		dr.findElement(By.xpath(xPath)).sendKeys(testdata);			
	}

	public static void clickButton(String xPath) {
		dr.findElement(By.xpath(xPath)).click();
	}

	public static String verify(String xPath, String test_Data) {
		String act =dr.findElement(By.xpath(xPath)).getText();
		String exp = test_Data;
		
		if(act.equals(exp)) 
			result = "PASS";
		
		else
		result = "FAIL";
		
		return result;
	}

}
