package hybrid;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_read {

	public static String filename= "C:\\Users\\rajat.agrawal\\Documents\\Book1.xlsx";
	public static String kw_sheet = "Sheet4";
	public static String tc_sheet = "Sheet3";
	//public static String LOGINDATA = "Sheet2";
	public static XSSFSheet kw_sh_obj, tc_sh_obj, td_sh_obj;
	public static ArrayList<login_test_data> td_al;
	
	public static XSSFSheet set_sheet(String sheetname) {
		
		XSSFSheet sh = null;
		
		try {
			File f = new File(filename);
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			sh = wb.getSheet(sheetname);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return sh;
	}
	
	public static tc_selection read_TC_SELECTION_SH(int j) {
		
		tc_selection td= new tc_selection();
		
	try {
		tc_sh_obj = set_sheet(tc_sheet);
		
		XSSFRow rw = tc_sh_obj.getRow(j);
		td.tcid = rw.getCell(0).getStringCellValue();
		td.flag = rw.getCell(1).getStringCellValue();
		td.no_steps =(int)rw.getCell(2).getNumericCellValue();
		td.test_data_sh = rw.getCell(3).getStringCellValue();	
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	return td;
	
   }
	
	public static keyword_sh read_kw_sh(int i) throws IOException{
		
		keyword_sh kw = new keyword_sh();
		kw_sh_obj = set_sheet(kw_sheet);
		
		XSSFRow rw = kw_sh_obj.getRow(i);
		
		kw.TC_ID = rw.getCell(0).getStringCellValue();
		
		//kw.step_no = rw.getCell(1).getStringCellValue();
		if(rw.getCell(1)==null || rw.getCell(1).getCellType()==Cell.CELL_TYPE_BLANK)
		{
			kw.step_no = null;
			
		}
		else {
			kw.step_no = rw.getCell(1).getStringCellValue();
		}
		//kw.Keyword = rw.getCell(2).getStringCellValue();
		
		if(rw.getCell(2)==null || rw.getCell(2).getCellType()==Cell.CELL_TYPE_BLANK)
		{
			kw.Keyword = null;
			
		}
		else {
			kw.Keyword = rw.getCell(2).getStringCellValue();
		}
		
		//kw.XPath = rw.getCell(3).getStringCellValue();
		
		if(rw.getCell(3)==null || rw.getCell(3).getCellType()==Cell.CELL_TYPE_BLANK)
		{
			kw.XPath = null;
			
		}
		else {
			kw.XPath = rw.getCell(3).getStringCellValue();
			//System.out.println(kw.XPath);
		}
		
		//kw.Test_Data = rw.getCell(4).getStringCellValue();
		
		if(rw.getCell(4)==null || rw.getCell(4).getCellType()==Cell.CELL_TYPE_BLANK)
		{
			kw.Test_Data = null;
			
		}
		else {
			kw.Test_Data = rw.getCell(4).getStringCellValue();
		}
		
		return kw;
		
	}
	
	public static void get_test_data(String shname, int total_rows, int total_cols) {
		
		td_sh_obj = set_sheet(shname);
		login_test_data tp;
		td_al = new ArrayList<login_test_data>();
		int r,c;
		for(r=1;r<=total_rows;r++) {
			tp = new login_test_data();
			tp.uid = td_sh_obj.getRow(r).getCell(0).getStringCellValue();
			tp.pwd = td_sh_obj.getRow(r).getCell(1).getStringCellValue();
			System.out.println("test data row:" +r+" "+ "uid:" +tp.uid +" "+ "pwd:" +tp.pwd);
			td_al.add(tp);
		}
	}
	
	public static void write_sheet1(int i,String res) {
		
		try {
			File f = new File(filename);
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet(kw_sheet);
			
			XSSFRow r = sh.getRow(i);
			XSSFCell c= r.createCell(5);
            c.setCellValue(res);
			
			FileOutputStream fout =new FileOutputStream(f);
			wb.write(fout);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
	
public static void write_sheet2(int i,String res) {
		
		try {
			File f = new File(filename);
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet(tc_sheet);
			
			XSSFRow r = sh.getRow(i);
			XSSFCell c= r.createCell(4);
            c.setCellValue(res);
			
			FileOutputStream fout =new FileOutputStream(f);
			wb.write(fout);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
	
}
