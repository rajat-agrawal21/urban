package hybrid;

import java.io.IOException;

import com.sun.istack.internal.logging.Logger;

public class HFW extends excel_read {

	static Logger log;
	static keyword_sh d = new keyword_sh();
	static tc_selection td = new tc_selection();
	static String filename = "C:\\Users\\rajat.agrawal\\Documents\\Book1.xlsx";
	
	
	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		
		String id,ch;
		int i,j,k=0;
		for(i=1;i<=3;i++) {
			td = read_TC_SELECTION_SH(i);
			if(td.flag.equals("Y")) {
				
				for(j=1;j<9;j++) {
					
					d= read_kw_sh(j);
					System.out.println("d.TC_ID: " + d.TC_ID);
					
					if(d.TC_ID.equals(td.tcid)) {
						System.out.println("yes");
						break;
					}
					else
						continue;
				}
				
			get_test_data(td.test_data_sh,2,2);
			//display_testdata();
			//System.out.println(j);
			for(login_test_data data: td_al) {
				
				for(k=j;k<=((j+td.no_steps)-1);k++){
					
					String testdata = " ";
					
					if(k==(j+2)) {testdata = data.uid;
					System.out.println("testdata: " +testdata);}
					
					if(k==(j+3)) {testdata  = data.pwd;
					System.out.println("testdata: " +testdata);}
					
					d= read_kw_sh(k);
					ch = d.Keyword;
					
					switch(ch) {
					case "launchBrowser" :
						all_methods.launchBrowser(d.XPath);
						break;
						
					case "enter_text":
							all_methods.enter_text(d.XPath,testdata);
							break;
							
					case "clickButton" :
						all_methods.clickButton(d.XPath);
						break;
						
					case "clickLink" :
						all_methods.clickButton(d.XPath);
						break;
						
					case "verify" :
						write_sheet1(k,all_methods.verify(d.XPath,d.Test_Data));
						System.out.println(k+ " " +all_methods.verify(d.XPath,d.Test_Data));
						break;
					
					}
						
					
				}
						
			if(k==(j+td.no_steps)) {
				System.out.println(i+": Pass");
				write_sheet2(i,"Pass");
			}
			else
			{
				System.out.println(i+": Fail");
				write_sheet2(i,"Fail");
			}
		}
	}
				
			
		}

	}

}
