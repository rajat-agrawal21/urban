package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test2 {

	WebDriver dr;
	
	@When("^User enters wrong login details$")
	public void m1() throws Throwable {	
		System.out.println("^User enters wrong login details$");
		
		dr= test1.dr;
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("rajata@gmail.com");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("12345");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
}
	
	@Then("^Home page is not displayed$")
	public void m2() throws Throwable {	
		
		//dr= test1.dr;
		String exp = "Login was unsuccessful Please correct the errors and try again.";
		String act = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
		
		SoftAssert sa= new SoftAssert();
		 sa.assertEquals(act, exp);
		 sa.assertAll();
	}
}
