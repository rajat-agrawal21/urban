package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {

	public static WebDriver dr;
	
	@Given("^Login page is displayed$")
	public void login_page_is_displayed() throws Throwable {   
		System.out.println("^Login page is displayed$");	
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		 dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
	}

	@When("^User enters login details$")
	public void user_enters_login_details() throws Throwable {	  
		System.out.println("^User enters login details$");	 
		
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("rajatmittald6@gmail.com");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("mittaldemo21");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
	}

	@Then("^Home page is displayed$")
	public void home_page_is_displayed() throws Throwable {	   
		System.out.println("^Home page is displayed$");	  
		
		String exp_email = "rajatmittald6@gmail.com";
		String ac_email = dr.findElement(By.xpath("//div[@class='header-links']/ul[1]/li[1]//a")).getText();
		
		SoftAssert sa= new SoftAssert();
		 sa.assertEquals(ac_email, exp_email);
		 sa.assertAll();
	}
	

}
