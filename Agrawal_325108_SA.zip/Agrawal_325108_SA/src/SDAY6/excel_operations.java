package SDAY6;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_operations {

	String data1;
		
		public String read_excel(int r,int c) {
					
			try {
				
				File f = new File("C:\\Users\\rajat.agrawal\\Documents\\Book2.xlsx");
				FileInputStream fin = new FileInputStream(f);
				XSSFWorkbook wb = new XSSFWorkbook(fin);
				XSSFSheet sh = wb.getSheet("Sheet15");
								
				XSSFRow row = sh.getRow(r);
				
				XSSFCell cell1 = row.getCell(c);
				data1 = cell1.getStringCellValue();											
		}
			catch (FileNotFoundException e) {
				  e.printStackTrace();	
				}
				catch( IOException e)
				{
					e.printStackTrace();
				}
			return data1;
	}
}
