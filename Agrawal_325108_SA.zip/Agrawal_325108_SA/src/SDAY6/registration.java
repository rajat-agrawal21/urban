package SDAY6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import SDAY3.demo1;

public class registration {
	static demo1 d1;
	
	public static demo1 registration1(demo1 d2) {
		
		d1 = new demo1();
		
		 String url = "http://demowebshop.tricentis.com/register";
			
			System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
			WebDriver dr = new ChromeDriver();
			dr.get(url);
		
			dr.findElement(By.xpath("//*[@id=\"gender-male\"]")).click();
			dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys(d2.fname);
			dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys(d2.lname);
			dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(d2.email);
			dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(d2.pwd);
			dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys(d2.cpwd);
				
		    dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
		
		String s  = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]")).getText();			
		String s1 = "Your registration completed";
		System.out.println(s);
		
		if(s.equals(s1)) {
			//System.out.println("Registration pass");
			d1.exp = d2.email;
			d1.act = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
			
			System.out.println("Expected result=" +d1.exp);
			System.out.println("Actual result=" +d1.act);
	}
		else System.out.println("Registration fails");
		
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		return d1;
	}
	
}
