package SDAY6;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import SDAY3.demo1;

public class NewTest6 {	
	demo1 d;
	demo1 dd;
	registration reg;
	
	@BeforeClass
	public void config() {
		d = new demo1();
		dd = new demo1();
		reg = new registration();
	}
		
	 @Test(dataProvider = "security")
	  public void test1(String f, String l, String e, String pwd1 , String cpwd1) {
		  //System.out.println("registration:" +f + " " + l + " " +email );
		  d.fname = f;
		  d.lname = l;
		  d.email= e;
		  d.pwd= pwd1;
		  d.cpwd= cpwd1;
		  dd = reg.registration1(d);
		  
		  SoftAssert sa = new SoftAssert();
		 sa.assertEquals(dd.act, dd.exp);
		  sa.assertAll();
	  }
	 
	 @DataProvider(name= "security")
	  public String[][] provide_data(){
		  
		  String [][] data = {{"Rajat","Agrawal" ,"rajat11gthjijjhghgbhjg@gmail.com","mittaldemo21","mittaldemo21"},
				              {"Aman", "Agrawal", "rajatmittaljghhvbnvhjgvfhjbg8@gmail.com","amanagrawal21","amanagrawal21"}};
		  return data;
		  }
		  
}
