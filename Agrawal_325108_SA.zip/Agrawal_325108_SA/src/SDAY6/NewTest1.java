package SDAY6;

import org.testng.annotations.Test;

public class NewTest1 {
	
	
  @Test(priority = 0)
  
  public void c() {
	  System.out.println("In test c");
	  
  }
  
 @Test(priority = 5)
  
  public void a() {
	  System.out.println("In test a");
	  
  }
 
 @Test(priority = 3)
 
 public void t() {
	  System.out.println("In test t");
	  
 }
}
