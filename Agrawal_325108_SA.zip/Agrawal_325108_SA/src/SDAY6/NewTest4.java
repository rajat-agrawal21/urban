package SDAY6;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class NewTest4 {
	
	
  @Test(dataProvider = "Security")
  public void login(String u, String v, String er) {
	  
	  System.out.println("login:" +u + " " +v + " " + er);
  }
  
  @DataProvider(name = "Security")
  public String [][] getdata(){
	  String [][]data= {{"uid1", "pwd1", "er1"},{}};
	  return data;
	  }
  }

