package SDAY6;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import SDAY4.login_data;
import SDAY4.test_login;

public class NewTest5 {
	test_login loginobj;
	login_data ldata,ldata_out;
	
	@BeforeClass
	public void config() {
		ldata = new login_data();
		ldata_out = new login_data();
		loginobj = new test_login();
	}
	
  @Test(dataProvider = "security")
  public void test1(String u, String p, String exp_res) {
	  System.out.println("login:" +u + " " + p );
	  ldata.uid = u;
	  ldata.pwd = p;
	  ldata.exp_res1= exp_res;
	  ldata_out= loginobj.login(ldata);
	  
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(ldata_out.act_res1, ldata_out.exp_res1);
	  sa.assertAll();
  }
  
  @DataProvider(name= "security")
  public String [][] getData(){
	  
	  String [][] data = {{"rajatmittald6@gmail.com","mittaldemo21", "SUCCESS"},
			  {"rajatmittald6@gmail.com", "hjvjhvjv", "FAILURE"}};
	  return data;
	  }
	  
  
}
