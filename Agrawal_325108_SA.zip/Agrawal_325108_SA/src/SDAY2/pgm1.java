package SDAY2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String url = "https://www.w3schools.com/html/html_tables.asp";
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get(url);
		
		String s =dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr[1]/th[3]")).getText();
		System.out.println(s);
		
		String x1= "//*[@id=\"customers\"]/tbody/tr[4]/td[1]";
		String s1=dr.findElement(By.xpath(x1)).getText();
		System.out.println(s1);
		
		String x2= "//*[@id=\"customers\"]/tbody/tr[2]/td[2]";
		String s2 =dr.findElement(By.xpath(x2)).getText();
		System.out.println(s2);
		
		String x3 = "//*[@id=\"customers\"]/tbody/tr[3]/td[3]";
		String s3 =dr.findElement(By.xpath(x3)).getText();
		System.out.println(s3);
		
		
	}

}
