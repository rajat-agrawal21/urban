package DAY2;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,k;
		
		for(i=1;i<=5;i++) {
			for(j = 2*(5-i);j>=0;j--)
			{
				System.out.print(" ");
			}
			for(k=1;k<=i;k++)
			  System.out.print(k + " ");
			// System.out.print("");
			System.out.println("");	
		}
		
	}
}
