package DAY7;

import java.util.ArrayList;
import DAY3.Student;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//int r1 =1;
		pgm1 excel = new pgm1();
		ArrayList<Student> std_alist = new ArrayList<Student>();
		
		std_alist = excel.read_Excel();
		excel.write_excel(std_alist);
		
	}

}
