package DAY8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel {
	
	public ArrayList<passenger> read_excel(){
		
		ArrayList<passenger> pass = new ArrayList<passenger>();
	
		for(int i=1;i<=4;i++) {
			passenger p = new passenger();
			
			try {
				
				File f = new File("C:\\Users\\rajat.agrawal\\Documents\\Book2.xlsx");
				FileInputStream fis = new FileInputStream(f);
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				XSSFSheet sh = wb.getSheet("Sheet2");
				
				XSSFRow r = sh.getRow(i);
				
				XSSFCell c = r.getCell(1);
				p.passenger_name = c.getStringCellValue();
				
				XSSFCell c1 = r.getCell(2);
				p.from = c1.getStringCellValue();
				
				XSSFCell c2 = r.getCell(3);
				p.to = c2.getStringCellValue();
				
				XSSFCell c3 = r.getCell(4);
				p.rate = (int)c3.getNumericCellValue();
				
				XSSFCell c4 = r.getCell(5);
				p.no_of_seats = (int)c4.getNumericCellValue();
				
				//XSSFCell c5 = r.getCell(6);
				//	p.Total = (int)c5.getNumericCellValue();
				
				p.total();
				pass.add(p);
				
		}
			
			catch(FileNotFoundException e){
				e.printStackTrace();
			}
			
			catch(IOException e){
				e.printStackTrace();
				
			}
			
				}
			return pass;
				
			}
	
	public void write_excel(ArrayList<passenger> pass1) {
		
		int row =1;
		try {
			File f = new File("C:\\Users\\rajat.agrawal\\Documents\\Book2.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet2");
			
			for(passenger p1 : pass1) {
				
				XSSFRow r = sh.getRow(row);
				XSSFCell c = r.createCell(6);
				c.setCellValue((int) p1.Total);
				row++;
			}
			
			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);
			
		}
		
		catch(FileNotFoundException e){
			e.printStackTrace();
		}
		
		catch(IOException e){
			e.printStackTrace();
		}
	}	
}

