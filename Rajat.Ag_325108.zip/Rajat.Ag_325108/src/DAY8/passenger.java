package DAY8;

public class passenger {
	
	public String passenger_name;
	public String from;
	public String to;
	public int rate;
	public int no_of_seats;
	public int Total;
	
	public void total() {
	this.Total= (this.rate)*(this.no_of_seats) ;
	}
	
}
