package DAY8;
import java.util.*;


public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		excel exc = new excel();
		ArrayList<passenger> pass_alist = new ArrayList<passenger>();
		
		pass_alist = exc.read_excel();
		exc.write_excel(pass_alist);
		
	}

}
