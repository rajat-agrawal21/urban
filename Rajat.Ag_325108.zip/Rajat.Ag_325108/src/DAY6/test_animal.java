package DAY6;

public class test_animal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		elephant e1 = new elephant();
		elephant e2 = new elephant();
		tiger t1 = new tiger();
		tiger t2 = new tiger();
		
		e1.nolegs = 4;
		e1.color = "black";
		e1.food = "sugarcane";
		e1.name = "Gajraj";
		e1.swim();
		e1.loading();
		e1.spraying();
		e1.display_elephant();
		
		
		e2.nolegs = 4;
		e2.color = "grey";
		e2.food = "grass";
		e2.name = "Ganesha";
		e2.swim();
		e2.loading();
		e2.spraying();
		e2.display_elephant();
		
		t1.nolegs = 4;
		t1.color = "orange";
		t1.food = "zebra flesh";
		t1.name = "Sherkhan";
		t1.climbs_tree();
		t1.mauls();
		t1.display2();
		
		t2.nolegs = 4;
		t2.color = "Golden";
		t2.food = "black buck";
		t2.name = "Bajirao";
		t2.climbs_tree();
		t2.mauls();
		t2.display2();
		
	}

}
