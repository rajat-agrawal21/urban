package DAY6;

public class Student {
	public int rollno;
	public	String name;
	public int sel;
	public int java;
	public float avg;
		
	public void average()
		{
			this.avg = (this.sel + this.java) / 2.0f;
		}
	
	public Student (String name, int rollno,int sel,int java)
	{
		this.name = name;
		this.rollno = rollno;
		this.sel = sel;
		this.java = java;
		this.average();
	}
}
