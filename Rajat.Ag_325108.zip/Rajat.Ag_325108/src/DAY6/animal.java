package DAY6;

public class animal {

	int nolegs;
	String color;
	String food;
	String name;
	
	public void eats() {
		System.out.println("the animal eats:" +food);
	}

	
	public void display() {
		System.out.println("No of legs:" +this.nolegs + " "+ "Skin color:" + this.color + " " + "Food:" +this.food + " "+ "Name:" +this.name);
	
	}
}
