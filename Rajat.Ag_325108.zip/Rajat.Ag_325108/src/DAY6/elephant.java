package DAY6;

public class elephant extends animal{
	
	int lot;
	int lotusks;
	
	public void swim() {
		System.out.println("Elephants swim");
	}
	
	public void spraying() {
		System.out.println("Elephant sprays using trunks");
	}
	
	public void loading() {
		System.out.println("The elephants were used to lift heavy loads");
	}
	
	public void display_elephant() {
		System.out.println("No of legs:" +this.nolegs + " " + "Skin color:" + this.color +" "+ "Food:" +this.food + " "+"name:" +this.name);
		
		System.out.println("Length of trunk:" +this.lot + " " + "Length of tusk:" +this.lotusks);
	}
	
}
