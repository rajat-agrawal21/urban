package DAY6;

//import java.sql.Array;

public class pgm1 {
	static int array1[] = new int[7];
	public static int[] arr1() {
		int i=0;
		for(int p=12;p<=30;p++) {
			if(p%3==0) {
				array1[i] = p;
				i++; 
			}
		}
		return array1;
	}
	
	static int array2[] = new int[7];
	
	public static int[] arr2() {
		int j=0;
		for(int q=10;q<=30;q++) {
			if(q%5==0) {
				array2[j] = q;
				j++; 
			}
		}
		return array2;
	}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub 
     int u[] = arr1();
     int v[] = arr2();
		 int i,j;
		 for(i=0;i<u.length;i++) {
			 for(j=0;j<v.length;j++) {	 
				 if(  (u[i]+v[j]) >30 && (u[i]+v[j]) <40  )
					 System.out.println(u[i] + "+" +v[j] + "=" + (u[i]+v[j]));	  } 
		 }
	}

}
