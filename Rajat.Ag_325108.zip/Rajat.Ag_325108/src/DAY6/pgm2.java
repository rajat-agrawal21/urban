package DAY6;

public class pgm2 {
	
	public static String[] extract_word(String str) {
		int p=0,l=0,l1=0,i=0;
		String[] s = new String[7];
		String s1;
		while( p != -1) {
			l = str.indexOf(" ", l+1);
			p =l;
			
			if(l== -1)
				l = str.length();
			
			s1 = str.substring(l1,l);
			s[i] =s1;
			i++;
			l1=l+1;
		}
		return s;
	}
	
	public static void count_print(String[] s) {
		int j=0;
		for(j=0;j<(s.length);j++) {
			String s2 = s[j];
			if(s2.length()>5)
				System.out.println(s2);
		}
	}
	
	public static void main(String [] args) {
		String str = "Hello I am working at Global logic";
		//String[] s = new String[7];
		//int i;
		
		String s3[] = extract_word(str);
		count_print(s3);
	}
}
