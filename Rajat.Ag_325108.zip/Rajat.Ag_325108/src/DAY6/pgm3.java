package DAY6;

import java.util.ArrayList;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str[] = {"Noida","GlobalLogic", "Delhi"};
		
		for(String s : str) 
			System.out.println(s);
		
		ArrayList<String> str_a1 = new ArrayList<String>();
		
		str_a1.add("Rakesh");
		str_a1.add("Mahesh");
		str_a1.add("Suresh");
		str_a1.add("mukesh");
		
		System.out.println("Before Insertion:" + str_a1);
		str_a1.add(2,"Priya");
		
		System.out.println("After Insertion:" + str_a1);
		str_a1.remove("Suresh");
		
		System.out.println("After Deletion:" + str_a1);
		
	}

}
