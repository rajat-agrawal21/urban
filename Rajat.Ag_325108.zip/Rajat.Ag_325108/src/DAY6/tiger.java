package DAY6;

public class tiger extends animal {
	int loteeth;
	int loclaw;
	
	public void climbs_tree() {
		System.out.println("the tiger can climb a tree");
	}
	
	public void mauls() {
		System.out.println("Tiger mauls its prey");
	}
	
	
	public void display2() {
		System.out.println("No of legs:" +this.nolegs + " " + "Skin ncolor:" + this.color + " "+ "food:" + this.food + " " + "name:" +this.name ) ;
		
		System.out.println("Length of teeth:" +this.loteeth);
		System.out.println("Length of claw:" +this.loclaw);
	}
}
