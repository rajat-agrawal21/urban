package DAY5;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int m = 282, n=6;
		
		int p = m/n;
		System.out.println(p);
		
		int a[] = {22,33,67};
		System.out.println(a[4]);
		
	}

}
