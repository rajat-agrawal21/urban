package DAY5;
import DAY4.Student;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			try {
				File f = new File("C:\\Users\\rajat.agrawal\\Documents\\Book2.xlsx");
				FileInputStream fis = new FileInputStream(f);
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				XSSFSheet sh = wb.getSheet("Sheet1");
				//XSSFRow r = sh.getRow(2);
				//XSSFCell c = r.getCell(0);
				
				XSSFRow r = sh.createRow(3);
				XSSFCell c = r.createCell(3);
				
				//String s = c.getStringCellValue();
				//System.out.println(s);
				
				c.setCellValue("Selennium Library");
				FileOutputStream fos = new FileOutputStream(f);
				wb.write(fos);
				
				String s = c.getStringCellValue();
				System.out.println(s);
				
			}
			
			catch(FileNotFoundException e){
				e.printStackTrace();
			}
			
			catch(IOException e){
				e.printStackTrace();
			}
	}

}
