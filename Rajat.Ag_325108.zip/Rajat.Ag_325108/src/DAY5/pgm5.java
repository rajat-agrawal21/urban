package DAY5;
import DAY3.Student;
public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		//int r1 =1;
		pgm4 excel = new pgm4();
		
		for(i=1;i<=2;i++) {
		Student s1 = excel.read_Excel(i); 
		s1.average();
		excel.write_excel(s1,i);
		}
	}

}
