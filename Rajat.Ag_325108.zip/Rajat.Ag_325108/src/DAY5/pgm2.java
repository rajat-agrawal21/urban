package DAY5;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try 
		{
			int num[] = {23,65,87};
			int b = num[5];
			System.out.println(b);
			
			int a=10, b1=0,c;
			c = a/b1;
			System.out.println(c);
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("In AE catch blk");
		}
		
		catch(ArrayIndexOutOfBoundsException ae) {
			System.out.println("In AI catch blk");
		}
		System.out.println("out of catch");
	}

}
