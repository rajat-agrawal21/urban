package DAY1;
import java.util.*;
public class pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a number a");
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		
		System.out.println("Enter a number b");
		Scanner sc1 = new Scanner(System.in);
		int b = sc1.nextInt();
		
		System.out.println("Enter a number c");
		Scanner sc2 = new Scanner(System.in);
		int c = sc2.nextInt();
		
		if(a>b && a>c)
			System.out.println("a is the largest");
		else if(b>c)
			System.out.println("b is the largest");
		else System.out.println("c is the largest");
		
		if(a<b && a<c)
			System.out.println("a is the smallest");
		else if(b<c)
			System.out.println("b is the smallest");
		else System.out.println("c is the smallest");
		
		sc.close();
		sc1.close();
		sc2.close();
	}

}
