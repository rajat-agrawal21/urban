package DAY3;

public class pgm4 {
	
	public static int max(int row[])
	{ int largest= row[0];
		for(int x=0;x<5;x++)
		{
			for(int y=x+1;y<5;y++)
			{
				if(largest < row[y])
					largest = row[y];
}
}
		
		System.out.println("Maximum value in row is:" +largest);
		return largest;
		}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int marks[][]= {{77,67,89,65,98},{76,45,67,87,54},{56,18,64,76,34}};
		
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<5;j++)
			{
				System.out.print(marks[i][j] + " ");
			}
			System.out.println();
			
		}
		for(int p=0;p<3;p++)
		{
			max(marks[p]);
		}
	}

}
