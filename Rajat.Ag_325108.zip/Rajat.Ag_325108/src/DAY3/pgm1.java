package DAY3;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int std[] = {54,43,78,53,83,79};
		float avg;
		int sum=0;
		
		for(int i=0;i<std.length;i++)
		{
			sum = sum+ std[i];
		}
		avg = sum/std.length;
		System.out.println(avg);
	}

}
