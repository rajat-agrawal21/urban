package DAY3;

public class pgm7 {
	public static void main(String args[]) {
		
		String s1 = "Noida",s3 = "noida", s4= "I am learning Java";
		int l = s1.length();
		System.out.println("Length::" +l);
		
		//int r = s1.compareTo(s3);
		int r1= s1.compareToIgnoreCase(s3);
		System.out.println(r1);
		
		s3 = s4.substring(3,8);
		System.out.println(s3);
		
		l= s4.indexOf("a");
		System.out.println(l);
		
		l= s4.indexOf("i",3);
		System.out.println(l);
	}

}
