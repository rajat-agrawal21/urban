package DAY3;

public class pgm2 {
	public static boolean IsEven(int num)
	{
		if(num % 2 == 0)
			return true;
		else 
			 return false;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum =0;
 int num[]= {21,34,91,59,16,25,29,74,49,82};
 for(int i=0; i<num.length;i++)
 {
	 if(IsEven(num[i]) == true)
		 sum = sum + num[i];
 }
 	System.out.println("Sum of even numbers is:" +sum);
 
	}

}
