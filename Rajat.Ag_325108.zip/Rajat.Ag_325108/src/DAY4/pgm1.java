package DAY4;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int bmax=4,cmax=1;
		for(int a=1;a<=3;a++)
		{
			for(int b=1;b<=bmax;b++)
			{
				System.out.print(" ");
			}
			for(int c=1;c<=cmax;c++)
			{
				System.out.print("1" + " ");
				
			}
			
			bmax=bmax-2;
			cmax = cmax +1;
			System.out.println("");
		} 
		
	}

}
