package DAY4;
import java.util.*;
public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter number of rows you want to print");
		Scanner sc =new Scanner(System.in);
		int row = sc.nextInt();
		
		int i,j,k;
		for(i=1;i<=row;i++) {
			for(j=row - i ;j>0;j--)
			{
				System.out.print(" ");
			}
			for(k=1;k<=i;k++)
			{
				System.out.print("1" + " ");
			}
			System.out.println();
		}
		sc.close();
	}

}
