package DAY4;

public class Student {
	int rollno;
	String name;
	int m1;
	int m2;
	float avg;
	
	public Student(int rollno,String name,int m1) {
		
		this.rollno=rollno;
		this.name = name;
		this.m1= m1;
	}
	
	public void show()
	{
		System.out.println("Name:" +this.name);
		System.out.println("Rollno:" +this.rollno);
		System.out.println("Marks:" +this.m1);

	}
	
	public static void main(String[] args) {
		
		Student s1= new Student(10,"Rakesh",85);
		Student s2= new Student(11,"Rajat",87);
		Student s3= new Student(12,"Aman",67);
		Student s4= new Student(13,"Ankit",56);
		
		s1.show();
		s2.show();
		s3.show();
		s4.show();
		
		
		// TODO Auto-generated method stub
		
	}

}
