package DAY4;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 String line = "I am working with GlobalLogic in Noida",s1;
 int l=0,l1=0,p=0;
 	
 		while(p!= -1) {
 		 l = line.indexOf(" ",l+1);
 		// System.out.println("l:" +l);
 		 //System.out.println("l1:" +l1);
 		p=l;
 		 if(l == -1) 
			 l= line.length();
 		s1 = line.substring(l1,l);
 		System.out.println(s1);
 		l1 =l+1;
 		}
 		 
 			//s1 = line.substring(l1,l+1);
 	 		//System.out.println(s1);
 			 
 		 }
	}


