package DAY4;

public class calc_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		calc c = new calc();
		int sum = c.add(5,10);
		System.out.println("First sum:" +sum);
		
		float s = c.add(2, 3,4.1f);
		System.out.println("Second sum:" +s);
		
	}

}
