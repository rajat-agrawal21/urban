package DAY9;

public class encap_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		encap enc = new encap();
		
		enc.setAccount_no(123);
		enc.setAccount_bal(25005);
		
		System.out.println("Account no. is:" +enc.getAccount_no() + " "+ "Account balance is:" + enc.getAccount_bal());
		
	}

}
