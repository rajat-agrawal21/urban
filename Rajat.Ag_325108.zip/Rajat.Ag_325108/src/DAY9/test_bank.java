package DAY9;

public class test_bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		bank b;
		
		b = new yes();
		System.out.println("YES roi:" + b.get_roi());
		
		b = new citi();
		System.out.println("CITI roi:" + b.get_roi());
	}

}
