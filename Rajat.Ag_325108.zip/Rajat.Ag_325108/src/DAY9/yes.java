package DAY9;

public class yes extends bank {
	
	public float get_roi() {
		return 6.5f;
	}
}
