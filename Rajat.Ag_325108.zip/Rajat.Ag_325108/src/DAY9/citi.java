package DAY9;

public class citi extends bank {
	
	public float get_roi() {
		return 5.4f;
	}
}
